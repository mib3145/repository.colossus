from lib import main


main.main()
